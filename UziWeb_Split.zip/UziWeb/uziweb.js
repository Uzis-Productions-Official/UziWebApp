// UziWeb App Logic (split file)
(function(){
// --- PWA Install Button ---
let deferredPrompt = null;
const installBtn = document.getElementById('installBtn');
installBtn.style.display = 'none';
const isFile = location.protocol === 'file:';

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.style.display = 'block';
});

installBtn.addEventListener('click', async () => {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    installBtn.style.display = 'none';
  } else {
    alert(isFile
      ? 'Local file mode detected. Use Chrome: More tools → Create shortcut… (Open as window) to install, or serve this folder via a local server to enable the PWA prompt.'
      : 'Install prompt not available yet. Try reloading once the page is served over HTTP/HTTPS.');
  }
});

// --- Register service worker ---
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(console.log);
  });
}

// --- Helpers/State ---
const $ = s => document.querySelector(s);
const view = $('#view');
const tabsEl = $('#tabs');
const statusText = $('#statusText');
const STATE = {
  tabs: [], // {id,title,history:[],index}
  activeId: null,
  incognito: false,
  closedTabs: [],
  bookmarks: JSON.parse(localStorage.getItem('uzi.bookmarks')||'[]'),
  history: JSON.parse(localStorage.getItem('uzi.history')||'[]'),
  downloads: JSON.parse(localStorage.getItem('uzi.downloads')||'[]'),
  kb: JSON.parse(localStorage.getItem('uzi.kb')||'[]'),
  theme: localStorage.getItem('uzi.theme') || 'dark',
  engine: localStorage.getItem('uzi.engine') || 'https://www.google.com/search?q=',
  restore: JSON.parse(localStorage.getItem('uzi.restore')||'true')
};
document.body.setAttribute('data-theme', STATE.theme);
$('#engine').value = STATE.engine;
$('#restoreTabs').checked = STATE.restore;

// Persist state (except in incognito)
function persist(){
  if(STATE.incognito) return;
  localStorage.setItem('uzi.bookmarks', JSON.stringify(STATE.bookmarks));
  localStorage.setItem('uzi.history', JSON.stringify(STATE.history.slice(-800)));
  localStorage.setItem('uzi.downloads', JSON.stringify(STATE.downloads.slice(-400)));
  localStorage.setItem('uzi.kb', JSON.stringify(STATE.kb.slice(-800)));
  localStorage.setItem('uzi.theme', STATE.theme);
  localStorage.setItem('uzi.engine', STATE.engine);
  localStorage.setItem('uzi.restore', JSON.stringify(STATE.restore));
  const session = STATE.tabs.map(t => ({ title:t.title, url:t.history[t.index]||null }));
  localStorage.setItem('uzi.session', JSON.stringify(session));
}

// --- Tabs ---
function createTab(initial){
  const id = crypto.randomUUID();
  const t = {id, title:'New Tab', history:[], index:-1};
  STATE.tabs.push(t); STATE.activeId = id; renderTabs();
  if(initial) navigateTo(initial, false); else showStart();
}
function renderTabs(){
  tabsEl.innerHTML='';
  STATE.tabs.forEach(t=>{
    const el = document.createElement('div'); el.className='tab'+(t.id===STATE.activeId?' active':''); el.dataset.id=t.id;
    el.onclick=()=>{ STATE.activeId=t.id; syncUI(); };
    const title=document.createElement('span'); title.textContent=t.title || '…';
    const close=document.createElement('span'); close.textContent='✕'; close.className='close'; close.title='Close';
    close.onclick=(e)=>{ e.stopPropagation(); closeTab(t.id); };
    el.append(title, close); tabsEl.append(el);
  });
  syncButtons();
}
function activeTab(){ return STATE.tabs.find(x=>x.id===STATE.activeId); }
function closeTab(id){
  const i = STATE.tabs.findIndex(x=>x.id===id); if(i<0) return;
  const t = STATE.tabs[i]; const url = t.history[t.index]||null;
  STATE.closedTabs.push({title:t.title, url});
  STATE.tabs.splice(i,1);
  if(!STATE.tabs.length) createTab(); else { STATE.activeId = STATE.tabs[Math.max(0,i-1)].id; syncUI(); }
}
function moveTab(delta){
  const i = STATE.tabs.findIndex(t=>t.id===STATE.activeId); if(i<0) return;
  const j = (i + delta + STATE.tabs.length) % STATE.tabs.length;
  STATE.activeId = STATE.tabs[j].id; syncUI();
}
function reopenClosed(){
  const last = STATE.closedTabs.pop(); if(!last) return;
  createTab(last.url || null); const t = activeTab(); if(last.title) t.title = last.title; renderTabs();
}

// --- URL & navigation ---
function normalize(input){
  input = input.trim(); if(!input) return '';
  const likely = /^(https?:\/\/|file:\/\/)/i.test(input) || (/\./.test(input) && !/\s/.test(input));
  if(likely) return /^(https?:)?\/\//i.test(input)? (input.startsWith('http')?input:`https:${input}`) : `https://${input}`;
  return STATE.engine + encodeURIComponent(input);
}
function navigateTo(input, newTab){
  const url = normalize(input); if(!url) return;
  if(newTab) createTab(url); else {
    const t=activeTab(); if(!t) return;
    t.history = t.history.slice(0, t.index+1);
    t.history.push(url); t.index++;
    load(url);
  }
  syncButtons();
}
function load(url){
  const t=activeTab(); if(!t) return;
  statusText.textContent='Loading…';
  $('#url').value = url;
  view.onload = () => {
    statusText.textContent='Loaded.';
    let title=url;
    try{ title = view.contentDocument?.title || url; }catch(e){ title = new URL(url).host; }
    t.title = (title||url).slice(0,90); renderTabs();
    if(!STATE.incognito){
      STATE.history.push({url, title:t.title, ts:Date.now()});
      learnFrom(url, t.title);
      tryExtract(url);
      persist();
      renderHistory(); renderKB();
    }
  };
  view.onerror = ()=> statusText.textContent='Load error.';
  view.src = url;
}
function showStart(){
  const start = `<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>
  <style>body{margin:0;font:16px system-ui;background:#0d0d0f;color:#e8e8f2;display:grid;place-items:center;height:100vh}
  .card{background:#15151a;border:1px solid #2f2f37;border-radius:16px;padding:26px;max-width:760px;box-shadow:0 10px 28px rgba(0,0,0,.6)}
  input{width:100%;padding:12px 14px;border-radius:12px;border:1px solid #2f2f37;background:#0f0f14;color:#e8e8f2}
  input:focus{outline:none;box-shadow:0 0 0 2px #7c3aed88}
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-top:12px}
  .tile{padding:12px;border-radius:12px;background:#1a1a1d;border:1px solid #2f2f37;color:#cfcfe4;text-decoration:none}
  a{color:#a78bfa}</style></head>
  <body><div class=card><h2 style="margin:0 0 8px">UziWeb</h2>
  <p style="margin:0 0 12px;color:#a6a6bb">Search or enter a URL, then press Enter.</p>
  <input id=q autofocus placeholder="https://… or keywords">
  <div class="grid" id="grid"></div>
  <script>const Q=document.getElementById('q');Q.addEventListener('keydown',e=>{if(e.key==='Enter'){parent.postMessage({uziGo:Q.value},'*')}});</script>
  </div></body></html>`;
  const blob = new Blob([start], {type:'text/html'});
  view.src = URL.createObjectURL(blob);
  statusText.textContent='Ready.';
}
window.addEventListener('message', e=>{ if(e.data && e.data.uziGo){ navigateTo(e.data.uziGo); } });

// --- Buttons & inputs ---
$('#go').onclick = ()=> navigateTo($('#url').value);
$('#url').addEventListener('keydown', e=>{ if(e.key==='Enter') navigateTo($('#url').value); });
$('#engine').addEventListener('change', e=>{ STATE.engine = e.target.value; persist(); });
$('#newtab').onclick = ()=> createTab();
$('#closetab').onclick = ()=>{ const t=activeTab(); if(t) closeTab(t.id); };
$('#back').onclick = ()=>{ const t=activeTab(); if(!t) return; if(t.index>0){ t.index--; load(t.history[t.index]); } syncButtons(); };
$('#forward').onclick = ()=>{ const t=activeTab(); if(!t) return; if(t.index < t.history.length-1){ t.index++; load(t.history[t.index]); } syncButtons(); };
$('#reload').onclick = ()=>{ const t=activeTab(); if(!t) return; if(t.index>=0) load(t.history[t.index]); };
$('#home').onclick = ()=> showStart();
$('#split').onclick = ()=> toggleSplit();
$('#incognito').onclick = ()=> toggleIncognito();
$('#toggleDownloads').onclick = ()=> togglePanel('panelDownloads');
$('#toggleBookmarks').onclick = ()=> togglePanel('panelBookmarks');
$('#toggleHistory').onclick = ()=> togglePanel('panelHistory');
$('#toggleKnowledge').onclick = ()=> togglePanel('panelKnowledge');
$('#toggleMedia').onclick = ()=> togglePanel('panelMedia');
document.querySelectorAll('[data-close]').forEach(b=> b.addEventListener('click', ()=>togglePanel(b.getAttribute('data-close')) ));

// Panels helpers
function togglePanel(id){
  const el = document.getElementById(id);
  if(!el) return;
  const open = el.classList.contains('show');
  document.querySelectorAll('aside.panel').forEach(p=> p.classList.remove('show'));
  if(!open) el.classList.add('show');
}

// Split view
let splitOn=false;
function toggleSplit(){
  const main = document.getElementById('main');
  splitOn = !splitOn;
  if(splitOn){
    main.classList.add('split');
    const v2 = document.createElement('iframe');
    v2.id='view2'; v2.className='view';
    v2.setAttribute('sandbox', view.getAttribute('sandbox'));
    main.appendChild(v2);
  }else{
    const v2 = document.getElementById('view2'); if(v2) v2.remove();
    main.classList.remove('split');
  }
}

// Incognito
function toggleIncognito(){
  STATE.incognito = !STATE.incognito;
  $('#incognito').innerHTML = STATE.incognito? '◐ Incognito: On' : '● Incognito: Off';
}

// Theme
$('#toggleTheme').onclick = ()=>{
  STATE.theme = (STATE.theme==='dark'?'light':'dark');
  document.body.setAttribute('data-theme', STATE.theme);
  $('#toggleTheme').textContent = 'Theme: ' + (STATE.theme==='dark'?'Dark':'Light');
  persist();
};

// Downloads
function renderDownloads(){
  const list = $('#downloadsList'); list.innerHTML='';
  if(!STATE.downloads.length){ list.innerHTML='<div class="badge">No downloads yet.</div>'; return; }
  STATE.downloads.slice().reverse().forEach(d=>{
    const row=document.createElement('div'); row.className='row';
    const left=document.createElement('div'); left.innerHTML='<div><strong>'+ (d.name||'file') +'</strong></div><div class="badge">'+d.url+'</div>';
    const open=document.createElement('button'); open.className='btn'; open.textContent='Open'; open.onclick=()=> window.open(d.url,'_blank');
    row.append(left, open); list.append(row);
  });
}
function downloadLink(url, suggested='download'){
  try{
    const a=document.createElement('a'); a.href=url; a.download=suggested; a.rel='noopener'; a.click();
    STATE.downloads.push({url, name:suggested, ts:Date.now(), mode:'direct'}); persist(); renderDownloads();
  }catch(e){
    // fallback to .url
    const blob = new Blob([`[InternetShortcut]\nURL=${url}\n`], {type:'text/plain'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=(suggested||'link')+'.url'; a.click();
    STATE.downloads.push({url, name:suggested+'.url', ts:Date.now(), mode:'shortcut'}); persist(); renderDownloads();
  }
}
$('#downloadCurrent').onclick = ()=>{
  const t=activeTab(); if(!t || t.index<0) return;
  const url=t.history[t.index]; const name=(t.title||'download').replace(/[\\/:*?"<>|]/g,'-');
  downloadLink(url, name);
};
$('#downloadUrlBtn').onclick = ()=>{
  const u = $('#downloadUrl').value.trim(); if(!u) return;
  downloadLink(u, 'file');
  $('#downloadUrl').value='';
};

// Bookmarks
function renderBookmarks(){
  const el = $('#bookmarksList'); el.innerHTML='';
  if(!STATE.bookmarks.length){ el.innerHTML='<div class="badge">No bookmarks yet.</div>'; return; }
  STATE.bookmarks.forEach((b,i)=>{
    const row=document.createElement('div'); row.className='row';
    const a=document.createElement('a'); a.href=b.url; a.textContent=b.title||b.url; a.onclick=(e)=>{e.preventDefault(); navigateTo(b.url,true);};
    const actions=document.createElement('div');
    const open=document.createElement('button'); open.className='btn'; open.textContent='Open'; open.onclick=()=> navigateTo(b.url,true);
    const del=document.createElement('button'); del.className='btn'; del.style.background='#3a1a22'; del.textContent='Delete'; del.onclick=()=>{ STATE.bookmarks.splice(i,1); persist(); renderBookmarks(); };
    actions.append(open, del); row.append(a, actions); el.append(row);
  });
}
$('#bookmarkBtn').onclick = ()=>{
  const t=activeTab(); if(!t || t.index<0) return;
  const url=t.history[t.index]; const title=t.title||url;
  if(STATE.bookmarks.some(x=>x.url===url)) return;
  STATE.bookmarks.push({title,url}); persist(); renderBookmarks();
};
$('#exportBookmarks').onclick = ()=>{
  const blob = new Blob([JSON.stringify(STATE.bookmarks,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='uziweb_bookmarks.json'; a.click();
};
$('#importBMFile').addEventListener('change', (e)=>{
  const f=e.target.files[0]; if(!f) return;
  const r=new FileReader(); r.onload=()=>{ try{ const arr=JSON.parse(r.result); if(Array.isArray(arr)){ STATE.bookmarks=arr; persist(); renderBookmarks(); } }catch{} };
  r.readAsText(f);
});
$('#clearBookmarks').onclick = ()=>{ STATE.bookmarks=[]; persist(); renderBookmarks(); };

// History
function renderHistory(){
  const el=$('#historyList'); el.innerHTML='';
  if(!STATE.history.length){ el.innerHTML='<div class="badge">No history yet.</div>'; return; }
  STATE.history.slice(-400).reverse().forEach(h=>{
    const row=document.createElement('div'); row.className='row';
    const a=document.createElement('a'); a.href=h.url; a.textContent=h.title||h.url; a.onclick=(e)=>{e.preventDefault(); navigateTo(h.url,true);};
    const meta=document.createElement('span'); meta.className='badge'; meta.textContent=new Date(h.ts).toLocaleString();
    row.append(a, meta); el.append(row);
  });
}
$('#exportHistory').onclick = ()=>{
  const blob = new Blob([JSON.stringify(STATE.history,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='uziweb_history.json'; a.click();
};
$('#clearHistory').onclick = ()=>{ STATE.history=[]; persist(); renderHistory(); };

// Knowledge (UziWebDev)
function renderKB(filter=''){
  const el=$('#kbList'); el.innerHTML='';
  const items = STATE.kb.filter(x=>{
    if(!filter) return true;
    const s = (x.query||'')+' '+(x.url||'')+' '+(x.title||'')+' '+(x.text||'');
    return s.toLowerCase().includes(filter.toLowerCase());
  }).slice(-600).reverse();
  if(!items.length){ el.innerHTML='<div class="badge">No knowledge yet.</div>'; return; }
  items.forEach(k=>{
    const row=document.createElement('div'); row.className='row';
    const left=document.createElement('div'); left.style.flex='1';
    const title=document.createElement('div'); title.innerHTML = (k.type==='search'?'🔎 ':'📄 ') + (k.title || k.query || k.url);
    const sub=document.createElement('div'); sub.className='badge'; sub.textContent=(k.url||'') + ' • ' + new Date(k.ts).toLocaleString();
    left.append(title, sub);
    const open=document.createElement('button'); open.className='btn'; open.textContent='Open'; if(k.url) open.onclick=()=> navigateTo(k.url,true);
    row.append(left, open); el.append(row);
  });
}
$('#kbSearch').addEventListener('input', e=> renderKB(e.target.value));
$('#exportKB').onclick = ()=>{
  const blob=new Blob([JSON.stringify(STATE.kb,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='uziweb_knowledge.json'; a.click();
};
$('#importKBFile').addEventListener('change', e=>{
  const f=e.target.files[0]; if(!f) return;
  const r=new FileReader(); r.onload=()=>{ try{ const arr=JSON.parse(r.result); if(Array.isArray(arr)){ STATE.kb=arr; persist(); renderKB(); } }catch(err){ alert('Invalid JSON'); } };
  r.readAsText(f);
});
$('#clearKB').onclick = ()=>{ STATE.kb=[]; persist(); renderKB(); };
function learnFrom(url, title){
  try{
    const u = new URL(url);
    if(u.hostname.includes('google.') && u.pathname.startsWith('/search')){
      const q=u.searchParams.get('q'); if(q) STATE.kb.push({type:'search', query:q, url, title:'Google: '+q, ts:Date.now()});
    } else {
      STATE.kb.push({type:'page', url, title, ts:Date.now()});
    }
  }catch(e){}
}
function tryExtract(currentUrl){
  try{
    const doc = view.contentDocument; if(!doc) return;
    const text = (doc.body?.innerText || '').trim().slice(0, 8000);
    if(text){
      const last = STATE.kb[STATE.kb.length-1];
      if(last && last.type==='page' && last.url===currentUrl){ last.text = text; persist(); }
    }
  }catch(e){}
}
$('#capturePage').onclick = ()=>{
  const t=activeTab(); if(!t || t.index<0) return;
  tryExtract(t.history[t.index]); renderKB();
};

// Status buttons/toggles
function syncButtons(){
  const t=activeTab();
  $('#back').disabled = !(t && t.index>0);
  $('#forward').disabled = !(t && t.index < t.history.length-1);
  $('#reload').disabled = !(t && t.index>=0);
}

// Session restore
function restoreSession(){
  if(!STATE.restore){ createTab(); return; }
  try{
    const session = JSON.parse(localStorage.getItem('uzi.session')||'[]');
    if(Array.isArray(session) && session.length){
      session.forEach(s => createTab(s.url || null));
      return;
    }
  }catch(e){}
  createTab();
}
$('#restoreTabs').addEventListener('change', e=>{
  STATE.restore = e.target.checked; persist();
});

// Keyboard shortcuts
window.addEventListener('keydown', (e)=>{
  if(e.ctrlKey && e.key==='t'){ e.preventDefault(); createTab(); }
  if(e.ctrlKey && e.key==='w'){ e.preventDefault(); const t=activeTab(); if(t) closeTab(t.id); }
  if(e.ctrlKey && e.key==='l'){ e.preventDefault(); $('#url')?.focus(); $('#url')?.select(); }
  if(e.altKey && e.key==='ArrowLeft'){ e.preventDefault(); $('#back').click(); }
  if(e.altKey && e.key==='ArrowRight'){ e.preventDefault(); $('#forward').click(); }
  if(e.ctrlKey && e.key==='Tab'){ e.preventDefault(); moveTab(e.shiftKey?-1:1); }
  if(e.ctrlKey && e.shiftKey && (e.key==='T'||e.key==='t')){ e.preventDefault(); reopenClosed(); }
});

// Init panels and data
function initPanels(){
  renderDownloads();
  renderBookmarks();
  renderHistory();
  renderKB();
}
initPanels();
restoreSession();

// ========= Media Downloader =========
const mediaUrl = document.getElementById('mediaUrl');
const mediaFetchBtn = document.getElementById('mediaFetch');
const mediaResult = document.getElementById('mediaResult');

async function fetchMedia(u){
  mediaResult.innerHTML = '<div class="badge">Fetching…</div>';
  try{
    const res = await fetch(u, {mode:'cors'});
    if(!res.ok) throw new Error('HTTP '+res.status);
    const ct = res.headers.get('content-type') || '';
    const isMedia = ct.startsWith('audio/') || ct.startsWith('video/');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const name = (u.split('/').pop() || (isMedia?'media':'file')).split('?')[0] || 'file';
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.textContent = 'Download '+name+' ('+(ct||'blob')+')';
    a.className = 'btn';
    mediaResult.innerHTML = '';
    mediaResult.appendChild(a);
    // Also list basic metadata
    const meta = document.createElement('div');
    meta.className = 'badge';
    meta.textContent = (isMedia?'Detected media • ':'File • ') + (ct||'unknown');
    mediaResult.appendChild(meta);
  }catch(err){
    // Fallback to saving a .url
    const blob = new Blob([`[InternetShortcut]\nURL=${u}\n`], {type:'text/plain'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='link.url'; a.textContent='Save link (.url)'; a.className='btn';
    mediaResult.innerHTML = '<div class="badge">Direct download blocked (CORS/DRM or requires auth). Use the saved link or open in a new tab.</div>';
    mediaResult.appendChild(a);
  }
}
if(mediaFetchBtn){
  mediaFetchBtn.addEventListener('click', ()=>{
    const u = (mediaUrl.value||'').trim();
    if(!u) return;
    fetchMedia(u);
  });
}
})();